package harbourValencia;

public class Package {
	private int number;
	private int weight;

	public Package() {

	}

	public Package(int num, int wgh) {
		number = num;
		weight = wgh;
	}

	public int getNumber() {
		return number;
	}

	public int getWeight() {
		return weight;
	}
}
